import { TOGGLE } from "../constants"

export const toggleAction = ()=>{
    return{
        type:TOGGLE
    }
} 