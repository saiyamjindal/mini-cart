import { SHOW_PRODUCTS } from "../constants"
export const showProducts = ()=>{
    return {
        type: SHOW_PRODUCTS
    }
}
